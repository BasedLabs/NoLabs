=============================
Automation and Infrastructure
=============================

Starting from 2020 release, automated testing and documentation builds are
performed by GitLab and GitLab Runner.

..  toctree::
    :maxdepth: 2

    gitlab-ci

